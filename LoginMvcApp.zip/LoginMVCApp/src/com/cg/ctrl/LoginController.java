package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.Service.LoginServiceImpl;
import com.cg.dto.Login;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig config=null;


	public LoginController() {
		super();
	}


	public void init(ServletConfig config) throws ServletException {

		super.init(config);
		this.config=config;

		System.out.println("cntrl servlet init");

	}


	public void destroy() {
		//pls no sop statement in servlet in exam 
		System.out.println("cntrl servlet destry");
	}


	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, 
			IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException,
			IOException {
		LoginServiceImpl logSer=new LoginServiceImpl();
		String action=request.getParameter("action");
		ServletContext ctx=config.getServletContext();
		String cn=(String)ctx.getInitParameter("compName");
		ctx.setAttribute("CompNameObj", cn);
		if(action!=null)
		{
			RequestDispatcher rd=null;

			/*************action ShowHomePage**********************/
			if(action.equalsIgnoreCase("ShowHomePage"))
			{
				//fetching details in login page
				ArrayList<Login> userList;
			     try {
					userList=logSer.getallUsers();
					request.setAttribute("UserListObj", userList);
					rd=request.getRequestDispatcher("pages/Login.jsp");
					rd.forward(request, response);
				} catch (Exception e) {
                    rd=request.getRequestDispatcher("pages/Error.jsp");
                    rd.forward(request, response);
					e.printStackTrace();
				}
				
				
				
				
				////////
				
				rd=request.getRequestDispatcher("pages/Home.jsp");
				rd.forward(request, response);
			}


			/*********action ShowLoginPage***********/
			if(action.equalsIgnoreCase("ShowLoginPage"))
			{
				rd=request.getRequestDispatcher("pages/Login.jsp");
				rd.forward(request,response);
			}

			/**************ValidateData******************/
			if(action.equalsIgnoreCase("ValidateData"))
			{
				System.out.println("2");
				String un=request.getParameter("txtUname");
				String pwd=request.getParameter("txtPwd");

				try 
				{
					Login user=logSer.getUserDetails(un);
					if(un.equalsIgnoreCase(user.getUsername())&&
							(pwd.equalsIgnoreCase(user.getPassword())))
					{
						System.out.println("step1");
						HttpSession session=request.getSession(true);
						session.setAttribute("UsernameObj", un);
						rd=request.getRequestDispatcher("pages/Success.jsp");
						rd.forward(request, response);

					}
					else
					{
						System.out.println("3");
						String errMsg="Incorrect password pLs Enter again";
						request.setAttribute("MsgObj", errMsg);
						rd=request.getRequestDispatcher
								//("pages/Login.jsp");
						("LoginController?action=ShowLoginpage");
						rd.forward(request, response);

					}

				} catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


			}

		}else{
			PrintWriter out=response.getWriter();
			out.println("no action defined.......");
		}

	}

}
