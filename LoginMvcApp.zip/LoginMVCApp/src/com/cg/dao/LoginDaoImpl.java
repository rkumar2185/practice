package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.util.DBUTIL;

public class LoginDaoImpl {
	Connection con = null;
	PreparedStatement pst=null;
	Statement st=null;
	ResultSet rs=null;
	

	public LoginDaoImpl(){
		super();
	}
	public Login getUserDetails(String unm)
			throws SQLException 
	{
		Login usr= null;
		con=DBUTIL.getCon();
		System.out.println("In dao get conne:"+con);
		String sql="SELECT * FROM LOGIN_TBL WHERE USER_NAME=?";
		// try {
		pst=con.prepareStatement(sql);
		pst.setString(1,unm);
		rs=pst.executeQuery();
		rs.next();
		usr = new Login(rs.getString("USER_NAME"),rs.getString("USER_PASS"));
		
		return usr;
	}
	//to retrieve all user id
	public ArrayList<Login> getAllUsers() throws Exception{
		ArrayList<Login> userList=new ArrayList<Login>();
		con=DBUTIL.getCon();
        st=con.createStatement();
        rs=st.executeQuery("SELECT * FROM LOGIN_TBL");
        while(rs.next()){
        	userList.add(new Login(rs.getString("USER_NAME"),rs.getString("USER_PASS")));
        	
        }
        return userList;
        
	}
}
