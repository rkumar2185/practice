package com.org.ems.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashSet;
import java.util.Set;

import com.cg.ems.dto.Employee;

public class DBUtil {
	public static HashSet<Employee> empSet
	= new HashSet<Employee>();
	static 
	{
		//empSet.add(new Employee(12345,"Khan", 
				//90000.0F, LocalDate.of(2014,Month.MARCH,03)));
		empSet.add(new Employee(1111,"Rai", 
				80000.0F, LocalDate.of(2054,Month.JULY,23)));
		empSet.add(new Employee(34567,"Aish", 
				70000.0F, LocalDate.of(2014,Month.JUNE,13)));
		empSet.add(new Employee(23456,"Kat", 
				60000.0F, LocalDate.of(2015,Month.MAY,23)));
		empSet.add(new Employee(12345,"Kaiut", 
				20000.0F, LocalDate.of(2111,Month.MAY,3)));
		
	}
	
	public static Set<Employee> getAllEmp()
	{
		return empSet;
	}
	public static void addEmp(Employee ee)
	{
		empSet.add(ee);
	}
	public static void remove(Employee temEmp){
		empSet.remove(temEmp);
	}
	public static void remove(float empSal) {
		// TODO Auto-generated method stub
		empSet.remove(empSal);
		
	}
}