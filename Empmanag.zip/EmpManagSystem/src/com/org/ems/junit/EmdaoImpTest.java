package com.org.ems.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ems.dto.Employee;
import com.org.ems.dao.EmployeeDaoImpl;
import com.org.ems.dao.Employeedao;
import com.org.ems.exception.EmployeeException;

public class EmdaoImpTest {
	static Employeedao empdao = null;

	@BeforeClass
	public static  void setUp()
	{
		empdao = new EmployeeDaoImpl();
		System.out.println("this function is called once"
	           +"before the execution of all tets cases");
	}
	@Before
	public  void init()
	{
		System.out.println("this function is called "
	           +"before the execution of each tets cases");
	}
	
	
	@After
	public void destroy()
	{
		System.out.println("this function is called "
		           +"after the execution of each tets cases");
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("this function is called once"
		           +"after the execution of all tets cases");
	}
	
	@Test
	public void testAddEmp() throws EmployeeException
	{
		Assert.assertEquals(111, empdao.
				addEmployee(new Employee(111,"aaa",1000.0f,null)));
	}
	
	@Test
	public void testfetAllEmp()
	{
		Assert.assertNotNull(empdao.fetchAllEmp());
	}

}
