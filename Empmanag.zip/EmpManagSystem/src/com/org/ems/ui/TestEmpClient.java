package com.org.ems.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.cg.ems.dto.Employee;
import com.org.ems.exception.EmployeeException;
import com.org.ems.service.EmployeeService;
import com.org.ems.service.EmployeeServiceImpl;

public class TestEmpClient {
	static EmployeeService empSer = null;
	// static Scanner sc = null;
	static BufferedReader br = null;

	public static void main(String[] args) throws NumberFormatException,
			IOException {
		empSer = new EmployeeServiceImpl();
		// sc = new Scanner(System.in);
		br = new BufferedReader(new InputStreamReader(System.in));
		int choice;
		while (true) {
			System.out.println("\n\n");
			System.out
					.println("************-:::WHAT DO YOU WANT:::-*************\n\n");
			System.out.println("1:Add Emp\t\t2:Get All Emp info\n");
			System.out.println("3:Update Emp\t\t4:Get Emp by Id\n");
			System.out.println("5:Search Emp by Name\t6:Delete Emp\n");
			System.out.println("7:Exit");
			choice = Integer.parseInt(br.readLine());
			performOperation(choice);
		}

	}

	/*
	 * int a = Integer.parseInt(br.readLine());
	 * System.out.println("Enter a String"); String b = br.readLine();
	 */

	private static void performOperation(int choice) throws IOException {
		// TODO Auto-generated method stub

		switch (choice) {
		case 1:
			addEmp();
			break;
		case 2:
			showEmpInfo();
			break;

		// case 3: UpdateEmp(); break;
		case 4:
			searchEmplbyId();
			break;
	
		  case 5: searchEmpByName(); 
		  break;
		 
		 case 6: deleteEmp(); 
		 break;
		
		default:
			System.exit(0);
		}

	}

	/*
	 * private static void UpdateEmp() { // TODO Auto-generated method stub
	 * 
	 * }
	 */

	
	  private static void deleteEmp() 
	  {
		  // TODO Auto-generated method stub
	  System.out.println("Enter employee Id to delete the employee details: ");
	  int epId = 0;
	try {
		epId = Integer.parseInt(br.readLine());
	} catch (NumberFormatException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  int ee = empSer.deleteEmp(epId); 
	  if (ee == 1) 
	  {
	  System.out.println("Data successfully deleted");
	  }
	  
	  
	  
	  }
	 

	
	  private static void searchEmpByName() 
	  { 
		  // TODO Auto-generated method
	 //  EmployeeServiceImpl empSer = new EmployeeServiceImpl();
	   
	  System.out.println("Enter employee Name to get the employee details: ");
	  String epName = null;
	try {
		epName = br.readLine();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
//	System.out.println("step1");
	  Employee ee = empSer.searchEmpByName(epName);
	 // System.out.println("step2");
	  System.out.println(epName);
	  System.out.println(ee);
	  
	  if (ee != null)
	  {
		 // System.out.println("step5");
		  System.out.println("EmpName:" + ee.getEmpId() +
	                  " Salary: " + ee.getEmpSal());
		 // System.out.println("step6");
	  }
	  else {
	  System.out.println("sorry no found"); 
	  }
	  
	  }
	 

	private static void searchEmplbyId() {

		System.out.println("Enter employee id to get the employee details: ");

		int epId = 0;
		try {
			epId = Integer.parseInt(br.readLine());
			System.out.println("\n");
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Employee ee = empSer.searchtEmpById(epId);

		if (ee != null) {
			System.out
					.println("<<<<<<<<<<    Employee Details   >>>>>>>>>>>\n");
			System.out.println("   EmpName:" + ee.getEmpName() + "\n\n"
					+ "   Salary: " + ee.getEmpSal());
		} else {
			System.out.println("sorry no found");
		}

	}

	private static void addEmp() throws IOException {
		while (true) {
			System.out.println("Enter Employee Name:");
			String ename = br.readLine();
			int eId = 0;
			float sal = 0.0F;
			try {
				if (empSer.validateName(ename))
					// to check validatio of name by user we
					// create service obj above
					System.out.println("Enter Employee Id");
				eId = Integer.parseInt(br.readLine());
				System.out.println("Enter Salary");
				sal = Float.parseFloat(br.readLine());

				Employee ee = new Employee(eId, ename, sal, null);
				empSer.addEmployee(ee);
				return;

			} catch (EmployeeException e) {
				e.printStackTrace();

			}
		}
	}

	private static void showEmpInfo() {

		Set<Employee> emps = empSer.fetchAllEmp();
		Iterator<Employee> itSet = emps.iterator();
		System.out.println("ID\t\tName\t\tSalary\t\tDateofJoin");
		System.out
				.println("....            ....            ........        .........");
		while (itSet.hasNext()) {
			Employee tempEmp = itSet.next();
			System.out.println(tempEmp.getEmpId() + "\t\t"
					+ tempEmp.getEmpName() + "\t\t" + tempEmp.getEmpSal()
					+ "\t\t" + tempEmp.getEmpDOJ());
		}

	}

}
