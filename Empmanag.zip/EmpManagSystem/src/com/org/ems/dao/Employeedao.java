package com.org.ems.dao;

import java.util.Set;

import com.cg.ems.dto.Employee;
import com.org.ems.exception.EmployeeException;

public interface Employeedao {
	public int addEmployee() throws EmployeeException;

	public Set<Employee> fetchAllEmp();

   public Employee searchtEmpById(int epId);

  public Employee searchEmpByName(String eName);

	  public int deleteEmp(int empId);

	int addEmployee(Employee ee) throws EmployeeException;

//	public Employee searchtEmpById(int epId);

//	public int UpdateEmp(int empId, float salary);

}
