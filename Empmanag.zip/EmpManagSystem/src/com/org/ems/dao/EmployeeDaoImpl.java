package com.org.ems.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.cg.ems.dto.Employee;
import com.org.ems.exception.EmployeeException;
import com.org.ems.service.EmployeeService;
import com.org.ems.util.DBUtil;

public class EmployeeDaoImpl implements Employeedao {

	@Override
	public Set<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return DBUtil.getAllEmp();
	}

	@Override
	public Employee searchtEmpById(int epId) {
		// TODO Auto-generated method stub
		Employee temEmp = null;
		// Employee temEmp2 = null;

		Set<Employee> emps = DBUtil.getAllEmp();
		// DBUtil.getAllEmp();
		Iterator<Employee> itSet = emps.iterator();
		/*
		 * System.out.println("EmpName:" + temEmp.getEmpName() + " Salary: " +
		 * temEmp.getEmpSal());
		 */

		while (itSet.hasNext()) {
			temEmp = itSet.next();
			/*
			 * System.out.println("EmpName:" + temEmp.getEmpName() + " Salary: "
			 * + temEmp.getEmpSal());
			 */
			if (temEmp.getEmpId() == epId)
				
			{
				// temEmp2 = temEmp;
				return temEmp;
			}

		}
		return null;

	}

	 @Override
	
	  public Employee searchEmpByName(String eName) { 
		 // TODO Auto-generated method stub 
		 //Employee empSer = new EmployeeService(); 
		 Employee temEmp=null;
		 //Employee temEmp2 = null;
	  
	  Set<Employee> emps = DBUtil.getAllEmp();
	 // Set<Employee> emps =fetchAllEmp();
	  Iterator<Employee> itSet = emps.iterator();
	 // System.out.println("step3");
	  while(itSet.hasNext()) 
	  { 
		//  System.out.println("step4");
		  temEmp=itSet.next();
		//  System.out.println(temEmp);
	  if(temEmp.getEmpName().equals(eName))
		  {
		 // System.out.println("step7");
		    return temEmp;
		  }

	  }
	       return null;
	  }
	 
	
	/*  @Override 
	  public int deleteEmp(int empId)
	  { 
		  Employee temEmp =null;
	  
	  //Employee temEmp2 = null;
	  
	  Set<Employee> emps = DBUtil.getAllEmp();
	  Iterator<Employee> itSet = emps.iterator();
	  while(itSet.hasNext()) 
	  { 
		  temEmp=itSet.next();
	  if(temEmp.getEmpId() == empId)
		  DBUtil.remove(temEmp);
	  } return 1; 
	  }
	*/

	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		// TODO Auto-generated method stub
		DBUtil.addEmp(ee);
		return ee.getEmpId();
	}

	@Override
	public int addEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteEmp(int empId) {
		Employee temEmp =null;
		  
		  //Employee temEmp2 = null;
		  
		  Set<Employee> emps = DBUtil.getAllEmp();
		  Iterator<Employee> itSet = emps.iterator();
		  while(itSet.hasNext()) 
		  { 
			  temEmp=itSet.next();
		  if(temEmp.getEmpId() == empId)
			  DBUtil.remove(temEmp);
		  } return 1; 
	}

	/*
	 * public void update(Set<A> data, A element) { data.remove(element); //
	 * Safe even if the element is not in the Set data.add(element);
	 */
	/*
	 * @Override public int UpdateEmp(int empId, float salary) { // TODO
	 * Auto-generated method stub
	 * 
	 * Employee temEmp =null; //Employee temEmp2 = null;
	 * 
	 * Set<Employee> emps = DBUtil.getAllEmp(); Iterator<Employee> itSet =
	 * emps.iterator(); while(itSet.hasNext()) { temEmp=itSet.next();
	 * if(temEmp.getEmpId() == empId) DBUtil.remove(temEmp.getEmpSal());
	 * 
	 * // DBUtil.add(Salary); } return 1; }
	 */

}
