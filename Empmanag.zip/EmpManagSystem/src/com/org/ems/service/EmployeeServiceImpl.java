package com.org.ems.service;

import java.util.Set;
import java.util.regex.Pattern;

import com.cg.ems.dto.Employee;
import com.org.ems.dao.EmployeeDaoImpl;
import com.org.ems.dao.Employeedao;
import com.org.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
    Employeedao empdao =null;
	 public EmployeeServiceImpl() {
		// TODO Auto-generated constructor stub
		empdao = new EmployeeDaoImpl();
	}
	
	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		
		return empdao.addEmployee(ee);
	}

	@Override
	public Set<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return empdao.fetchAllEmp();
	}

	@Override
	public Employee searchtEmpById(int epId) {
		// TODO Auto-generated method stub
		return empdao.searchtEmpById(epId);
	}

	@Override
	public Employee searchEmpByName(String eName) {
		// TODO Auto-generated method stub
		return empdao.searchEmpByName(eName);
	}
	

	@Override
	public int deleteEmp(int empId) {
		// TODO Auto-generated method stub
		return (int) empdao.deleteEmp(empId);
	}
/*
	@Override
	public int UpdateEmp(int empId, float salary) {
		// TODO Auto-generated method stub
		return  empdao.UpdateEmp (empId, salary);
	}*/


	/*@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}*/

	@Override
	public boolean validateName(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		String namePatter="[A-Z][a-z]+";
		if(Pattern.matches(namePatter, name))
		{
			return true;
		}
		else
		{
			throw new EmployeeException	("Invalid Name should start with capital and only"
					+ "Charaters allowed");
		
		}
	}

	@Override
	public boolean validateId(int id) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateDate(String date) throws EmployeeException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int addEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

/*	@Override
	public int UpdateEmp(int empId, float salary) {
		// TODO Auto-generated method stub
		return empdao.UpdateEmp(empId,salary);
	}*/

	/*@Override
	public Employee getDetails(int epId) {
		// TODO Auto-generated method stub
		return empdao.getDetails(epId);
	}*/

}
