package com.org.ems.service;
//package com.org.ems.dao;

import java.util.Set;

import com.cg.ems.dto.Employee;
import com.org.ems.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee() throws EmployeeException;

	public Set<Employee> fetchAllEmp();

	public Employee searchtEmpById(int epId);

		public Employee searchEmpByName(String eName);
	

	public int deleteEmp(int empId);
	/*	
	public int UpdateEmp(int empId,float salary);*/

	int addEmployee(Employee ee) throws EmployeeException;
	
	public boolean validateName(String name)throws EmployeeException;
	public boolean validateId(int id)throws EmployeeException;
	public boolean validateDate(String date)throws EmployeeException;

//	public Employee searchtEmpById(int epId);

	//public Employee getDetails(int epId);
	

}
