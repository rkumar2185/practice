package com.cg.pizzaorder.junit;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class UnitTesting {

	@Test
	public void testPlaceOrder() throws PizzaException{
		Customer c=new Customer(1234,"keshav","Capgemini","9897168675");
		PizzaOrder po=new PizzaOrder(1111,1234,420);
		IPizzaOrderService pos=new PizzaOrderService();
		int tsetID=pos.placeOrder(c, po);
		Assert.assertEquals(1111,tsetID);
	}
	
	@Test
	public void testFetchAllOrders() throws PizzaException{
		Customer c1=new Customer(1234,"keshav","Capgemini","9897168675");
		PizzaOrder po1=new PizzaOrder(1111,1234,420);
		Customer c2=new Customer(4352,"keshav","Capgemini","9897168675");
		PizzaOrder po2=new PizzaOrder(1001,4352,420);
		IPizzaOrderService pos1=new PizzaOrderService();
		IPizzaOrderService pos2=new PizzaOrderService();
		pos1.placeOrder(c1, po1);
		pos2.placeOrder(c2, po2);
		Assert.assertNotNull(pos1.pizzOrderDataSet());
		Assert.assertNotNull(pos2.pizzOrderDataSet());
		
		
	}

}
