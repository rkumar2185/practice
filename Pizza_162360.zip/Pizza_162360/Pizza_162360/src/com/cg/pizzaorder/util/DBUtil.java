package com.cg.pizzaorder.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class DBUtil {
	public static Map<Integer,PizzaOrder> pizzor=new HashMap<Integer, PizzaOrder>();
	public static Map<Integer,Customer> cstmr=new HashMap<Integer, Customer>();
	
	public static int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException
	{
		pizzor.put(pizza.getOrderId(),pizza );
		cstmr.put(customer.getCustomerId(), customer);
		return pizza.getOrderId();
	}
	
	public static PizzaOrder getOrderDetails(int orderid) throws PizzaException
	{
		Map<Integer,PizzaOrder> pizz = pizzor;
		Iterator<PizzaOrder> it= pizz.values().iterator();
		while(it.hasNext())
		{
			PizzaOrder porder=it.next();
			if(porder.getOrderId()==orderid)
			{
				return porder;
			}
		}
		return null;
	}
	public static Map<Integer, PizzaOrder> pizzOrderDataSet() throws PizzaException
	{
		return pizzor;
	}
}
