package com.cg.btva.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.btva.bean.BusDetails;
import com.cg.btva.dao.BusDao;

/*
 * This is the service layer of application
 */

@Service
public class BusServiceImpl implements BusService {

	@Autowired
	private BusDao dao;
	
	
	public BusDao getDao() {
		return dao;
	}

	public void setDao(BusDao dao) {
		this.dao = dao;
	}


	//This method is to call dao layer
	@Override
	public List<BusDetails> getAllBusDetails() {
		return dao.getAllBusDetails();
	}

}
