package com.cg.btva.service;

import java.util.List;

import com.cg.btva.bean.BusDetails;

public interface BusService {

	List<BusDetails> getAllBusDetails();

}
