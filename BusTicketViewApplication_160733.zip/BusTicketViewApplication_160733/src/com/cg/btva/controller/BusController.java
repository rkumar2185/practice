package com.cg.btva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.btva.bean.BusDetails;
import com.cg.btva.exception.BusException;
import com.cg.btva.service.BusService;

@Controller
public class BusController {

	@Autowired
	private BusService service;
		
	public BusService getService() {
		return service;
	}

	public void setService(BusService service) {
		this.service = service;
	}
    
	//This method is to show Home Page of the application
	@RequestMapping("/showHomePage")
	public String showHomePage() {
		return "menu";
	}
	
	//This method is to show the details
	@RequestMapping("/showBusDetails")
	public ModelAndView showBusDetails() throws BusException {

		ModelAndView mv = new ModelAndView();
        try{
		List<BusDetails> list = service.getAllBusDetails();
		mv.setViewName("viewAllBusses");
		mv.addObject("list", list);
		
        }catch(Exception ex){
        	throw new BusException("There are no Busses availabe!!!");
        }
        
		return mv;
	}
}
