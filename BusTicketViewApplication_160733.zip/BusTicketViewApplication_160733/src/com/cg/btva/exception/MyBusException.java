package com.cg.btva.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

/*
 * This class is for handling the exceptions
 * Author : Capgemini
 * 
 */
@ControllerAdvice
public class MyBusException {

	@ExceptionHandler(value = { Exception.class })
	public ModelAndView handleConflict(Exception ex, HttpServletRequest req) {
		ModelAndView mv = new ModelAndView();
		String bodyOfResponse = ex.getMessage();
		String uri = req.getRequestURL().toString();

		ErrorInfo errorInfo = new ErrorInfo(uri, bodyOfResponse);
		mv.setViewName("error");
		mv.addObject("errorInfo", errorInfo);
		
		return mv;
	}
}
