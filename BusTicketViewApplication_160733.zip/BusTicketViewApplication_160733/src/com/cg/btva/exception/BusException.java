package com.cg.btva.exception;

public class BusException extends Exception {


	/**This is the user defined exception class
	 * Author:Capgemini
	 */
	private static final long serialVersionUID = 1L;

	public BusException() {
		super();
	}

	public BusException(String message) {
		super(message);
	}
}
