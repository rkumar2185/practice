package com.cg.btva.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.btva.bean.BusDetails;

/*
 * This is the dao layer of the application
 */

@Repository
@Transactional
public class BusDaoImpl implements BusDao {

	@PersistenceContext
	private EntityManager entityManager;

	//This method is to get details from the database
	@Override
	public List<BusDetails> getAllBusDetails() {
		TypedQuery<BusDetails> query = entityManager.createQuery("SELECT b FROM BusDetails b", BusDetails.class);
		return query.getResultList();
	}

}
