package com.cg.btva.dao;

import java.util.List;

import com.cg.btva.bean.BusDetails;

public interface BusDao {

	List<BusDetails> getAllBusDetails();

}
