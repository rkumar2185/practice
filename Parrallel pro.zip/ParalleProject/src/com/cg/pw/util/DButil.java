package com.cg.pw.util;


	

	import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.Map;

import com.cg.pw.dto.Customer;



	public class DButil{
	    
	    static int s=23455;
	    public static HashMap<Integer,Customer> cusMap = new HashMap<Integer,Customer>();
	    static{
	    	cusMap.put(1,(new Customer("Rohan","6565656565","Haryana","rohan.kumar@gmail.com","1231234567897412")));
	    	cusMap.put(2,(new Customer("Rhan","7565656565","Hryana","rhan.kumar@gmail.com","2231234567897412")));
	    	cusMap.put(3,(new Customer("Ran","8565656565","Hyana","ran.kumar@gmail.com","3231234567897412")));
	        cusMap.put(4,(new Customer("Rn","9565656565","Hana","rn.kumar@gmail.com","4231234567897412")));
	    }
	    public static void createAccount(Customer ee){
	    	cusMap.put(s++,ee);
	        
	    }
	    public static Map<Integer,Customer> getAllEmp(){
	        return cusMap;
	    }}




