package com.cg.pw.dao;

import java.util.Map;

import com.cg.pw.dto.Customer;

public interface WalletDao {
	  public int createAccount(Customer ee);
	  public int Deposit(int Amount,Customer ee);
	  
	  

}
