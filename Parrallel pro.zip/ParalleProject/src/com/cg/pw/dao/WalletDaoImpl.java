package com.cg.pw.dao;

import java.util.Map;
import java.util.Scanner;

import com.cg.pw.dto.Customer;
import com.cg.pw.util.DButil;

public class WalletDaoImpl implements WalletDao{
	
	@Override
	public int createAccount(Customer ee) {
		DButil.createAccount(ee);
		return 1;
	}
}
	
	
	 
