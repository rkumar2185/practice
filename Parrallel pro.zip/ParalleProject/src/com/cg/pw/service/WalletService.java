package com.cg.pw.service;

import com.cg.pw.dto.Customer;
import com.cg.pw.exception.CustomerException;

public interface WalletService {
	
		  public int createAccount(Customer ee);
		  public boolean validateName(String eName)throws CustomerException ;
		    public boolean validatePhnNm(String phnNo) throws CustomerException ;
		    public boolean   validateMailId(String mailId)    throws CustomerException  ;
		    public boolean validateAdhar(String adharNo) throws CustomerException ;
		    
		

}
