package com.cg.pw.service;

import java.util.regex.Pattern;

import com.cg.pw.dao.WalletDao;
import com.cg.pw.dao.WalletDaoImpl;
import com.cg.pw.dto.Customer;
import com.cg.pw.exception.CustomerException;

public class WalletServiceImpl implements WalletService{
	WalletDao waDao = null;
	
	public WalletServiceImpl(){
		waDao = new WalletDaoImpl();
	}

	@Override
	public int createAccount(Customer ee) {
		return waDao.createAccount(ee);
	}

	@Override
	public boolean validateName(String eName) throws CustomerException {
		  String myPattern = "[A-Z][a-z]+";
	        if(Pattern.matches( myPattern,eName)){
	            return true;
	        }
	        else {
	            throw new CustomerException(" OOOHHH!  Invalid input , Sorry  "
	                + " Only Char are  allowed  and should start"
	                + " with Capital ex.Lovely  :)");
	        }
	}

	@Override
	public boolean validatePhnNm(String phnNo) throws CustomerException {
		 String myPattern = "[7-9][0-9]{9}+";
	        if(Pattern.matches( myPattern,phnNo)){
	            return true;
	        }
	        else {
	            throw new CustomerException(" OOOHHH!  Invalid input , Sorry  "
	                + " code+ first letter 7-9  and should start"
	                + " and 10 digit :)");
	        }
	}

	@Override
	public boolean validateMailId(String mailId) throws CustomerException {
		 String myPattern = "[a-z]+@gmail.com";
	        if(Pattern.matches( myPattern,mailId)){
	            return true;
	        }
	        else {
	            throw new CustomerException(" OOOHHH!  Invalid input , Sorry  "
	                + " "
	                + " with @gmail.com  :)");
	        }
	}

	@Override
	public boolean validateAdhar(String adharNo) throws CustomerException {
		 String myPattern = "[0-9]{8}";
	        if(Pattern.matches( myPattern,adharNo)){
	            return true;
	        }
	        else {
	            throw new CustomerException(" OOOHHH!  Invalid input , Sorry  "
	                + " unique id"
	                + " 8 digits are allowed  :)");
	        }}}




