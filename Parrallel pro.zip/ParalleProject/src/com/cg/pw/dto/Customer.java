package com.cg.pw.dto;

public class Customer {
	private String CusName;
	private String phnNo;
    private String add;
    private String mailId;
    private String adharNo;
    
    
    
	public Customer(String cusName, String phnNo, String add, String mailId,
			String adharNo) {
		super();
		CusName = cusName;
		this.phnNo = phnNo;
		this.add = add;
		this.mailId = mailId;
		this.adharNo = adharNo;
	}
	
	public String getCusName() {
		return CusName;
	}
	public String getPhnNo() {
		return phnNo;
	}
	public String getAdd() {
		return add;
	}
	public String getMailId() {
		return mailId;
	}
	public String getAdharNo() {
		return adharNo;
	}
	public void setCusName(String cusName) {
		CusName = cusName;
	}
	public void setPhnNo(String phnNo) {
		this.phnNo = phnNo;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}

	@Override
	public String toString() {
		return "Customer [CusName=" + CusName + ", phnNo=" + phnNo + ", add="
				+ add + ", mailId=" + mailId + ", adharNo=" + adharNo + "]";
	}
	
	
    
    
	
}
