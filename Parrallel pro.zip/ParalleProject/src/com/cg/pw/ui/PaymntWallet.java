package com.cg.pw.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.pw.dto.Customer;
import com.cg.pw.exception.CustomerException;
import com.cg.pw.service.WalletService;
import com.cg.pw.service.WalletServiceImpl;
import com.cg.pw.util.DButil;

public class PaymntWallet {
	static BufferedReader br = null;
	static WalletService wser = null;

	public static void main(String[] args) {
		wser = new WalletServiceImpl();

		br = new BufferedReader(new InputStreamReader(System.in));

		int choice = 0;
		while (true) {
			System.out.println("\n");
			System.out
					.println("*******WOW we have an option...lets do it********");
			System.out.println("\n");
			System.out.println("1. Create Account \t2. Show Balance");
			System.out.println("3. Deposit\t\t4. Withdraw");
			System.out.println("5. Fund Transfer\t6. Print Transaction");
			System.out.println("7. Exit");
			System.out.println("*******************************");
			System.out.println("Enter ur choice: ");

			try {
				choice = Integer.parseInt(br.readLine());
				performOperation(choice);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			performOperation(choice);
		}

	}

	private static void performOperation(int choice) {

		switch (choice) {
		case 1:
			// System.out.println("hi");
			CreateAccount();
			break;
		case 2:
			ShowBalance();
			break;
		case 3:
			Deposit();
			break;
		case 4:
			Withdraw();
			break;
		case 5:
			FundTransfer();
			break;
		case 6:
			printTransaction();
			break;
		default:
			System.exit(0);
		}
	}

	private static void printTransaction() {
		// TODO Auto-generated method stub

	}

	private static void FundTransfer() {
		// TODO Auto-generated method stub

	}

	private static void Withdraw() {
		// TODO Auto-generated method stub

	}

	private static void Deposit() {
		// TODO Auto-generated method stub

	}

	private static void ShowBalance() {
		// TODO Auto-generated method stub

	}

	private static void CreateAccount() {
		// System.out.println("step1");
		while (true) {
			System.out.println("Enter Your name: ");
			String eName = null;
			try {
				eName = br.readLine();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				if (wser.validateName(eName)) {
					System.out.println("Enter your Phone No.: ");
					String phnNo = br.readLine();
					try {
						if (wser.validatePhnNm(phnNo)) {
							System.out.println("Enter your addres:");
							String add = br.readLine();

							System.out.println("Enter your mailId.: ");
							String mailId = br.readLine();
							try {
								if (wser.validateMailId(mailId)) {
									System.out.println("Enter your adharNo:");
									String adharNo = br.readLine();
									try {
										if (wser.validateAdhar(adharNo)) {
											Customer ee = new Customer(eName,
													phnNo, add, mailId, adharNo);
											int f = wser.createAccount(ee);
											if (f == 1) {
												System.out
														.println("Please Verify your Details \n"

																+ "If Ok! press 1 else 0");
												System.out
														.println("****************Welcome "
																+ eName
																+ " Verify your Details**************************");

												System.out.println("\n");
												Map<Integer, Customer> emps = DButil
														.getAllEmp();
												Iterator<Integer> itKey = emps
														.keySet().iterator();
												Iterator<Customer> it = emps
														.values().iterator();
												while (it.hasNext()) {
													Customer temp = it.next();
													int it1=itKey.next();
													if (temp.getAdharNo() == adharNo) {
														System.out
																.println("Customer A/c No:"
																		+ it1
																		+ " [CusName="
																		+ temp.getCusName()
																		+ ", CusPhn No="
																		+ temp.getPhnNo()
																		+ ", CusAddress:="
																		+ temp.getAdd()
																		+ ",Adhar No="
																		+ temp.getAdharNo()
																		+ ", Cusmail Id="
																		+ temp.getMailId()
																		+ "]");
													}

												}
												System.out
														.println("Enter Your Response after Verification:");
												int choice1 = Integer
														.parseInt(br.readLine());
												if (choice1 == 1) {
													System.out
															.println("You are lucky , "
																	+ "Your Account Created  Successfully , Account Details will be sent your mail Id shortly\n");
												} else {
													CreateAccount();

												}

											
												break;
											} else if (f == 0) {
												System.out
														.println("oos! Some Error Occured. ");
											}
										}
									} catch (CustomerException e) {
										System.out.println(e.getMessage());
									}
								}
							}

							catch (CustomerException e) {
								System.out.println(e.getMessage());
							}
						}
					} catch (CustomerException e) {
						System.out.println(e.getMessage());
					}
				}
			}

			catch (CustomerException e) {
				System.out.println(e.getMessage());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}
}
