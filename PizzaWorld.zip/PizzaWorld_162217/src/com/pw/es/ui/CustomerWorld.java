package com.pw.es.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;

import com.pw.es.bean.Customer;
//import com.pw.es.bean.PizzaOrder;
import com.pw.es.exception.PizzaException;
import com.pw.es.service.IPizzaOrderService;
import com.pw.es.service.PizzaOrderService;


	public class CustomerWorld  
	{
		private static final String Capsicum = null;
		static BufferedReader br = null;
		static IPizzaOrderService empSer=null;
		public static void main(String[] args)
		{
			br = new BufferedReader(new InputStreamReader(System.in));
			empSer=new PizzaOrderService();
			int choice=0;
			while(true)
			{
				System.out.println("******U ar an emotional eater. If something's worth celebrating, you'r going to grab pizza******");
				System.out.println("\n");
				System.out.println("1:Place order :)\t2:Display Order :)\n");
				System.out.println("3:Exit\n");
				System.out.println(" Whats UR Choice");
				try {
					choice = Integer.parseInt(br.readLine());
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				switch(choice)
				{
				case 1:PlaceOrder();break;
				case 2:DisplayOrder();break;
				default:System.exit(0);
				}		
			}
		}
	

	
		private static void DisplayOrder() 
		{
			Map<Integer,Customer> empSet=empSer.fetchAllEmp();
			Iterator<Map.Entry<Integer, Customer>> it = empSet.entrySet().iterator();
			System.out.println("---------------------------");	
			System.out.println("ID\t\tCustomerName\t\tAddress\t\tPhone");		
			while(it.hasNext())
			{
				 Map.Entry<Integer,Customer> ee = it.next();
				 System.out.println(ee);
			}	
			
		}
		private static void PlaceOrder()
		{		
			
						while(true)
						{
							System.out.println(" Enter the name of the customer:");
							String cusName = null;
							try {
								cusName= br.readLine();
							} catch (IOException e1) {
								e1.printStackTrace();
							}
								System.out.println("Enter customer address: ");
								String addres = null;
								try {
									addres= br.readLine();
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								
								System.out.println("Enter customer Phone Number:");
								String phnNo = null ;
								try {
									phnNo= br.readLine();
								} catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								try{
								if(empSer.validatePhnNo(phnNo))
								{
									System.out.println("Type Of pizza Topping Preferred:");
									System.out.println("Capsicum\tmushroom\tjalapeno\tPaneer");	
									String topping = null ;
									try {
										topping= br.readLine();
									} catch (IOException e1) {
										e1.printStackTrace();
									}
									System.out.println("Total Price:");
									int total =350;
									if (topping == Capsicum)
									  total += 30;
									String mushroom = null;
									if (topping == mushroom)
										  total += 50;
									String Jalapeno = null;
									if (topping == Jalapeno)
										  total += 70;
									String Paneer = null;
									if (topping == Paneer)
										  total += 85;
									
									System.out.println(total);
									
									System.out.println("Order Date:" );
									
								
								Customer ee=new Customer(
										cusName,addres,phnNo);
									empSer.addEmployee(ee);

									/*PizzaOrder ee=new PizzaOrder(
											Integer.parseInt(eid),enam,su,LocalDate.now());
										empSer.addEmployee(ee);*/
									System.out.println(" Pizza Order successfully Placed with order id :");
									break;
}
}
catch(PizzaException e)
{
System.out.println(e.getMessage());
}

break;
						}}}

		
	



