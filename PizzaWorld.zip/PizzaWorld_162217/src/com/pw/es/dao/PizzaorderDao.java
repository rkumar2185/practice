package com.pw.es.dao;

import java.util.Map;

import com.pw.es.bean.Customer;
import com.pw.es.bean.PizzaOrder;
import com.pw.es.exception.PizzaException;
import com.pw.es.util.CollectionUTIL;

public class PizzaorderDao implements IPizzaOrderDAO {

	@Override
	public int placeOrder(Customer customer,PizzaOrder pizza) throws PizzaException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid)
			throws PizzaException {
		return null;
	}

	@Override
	public String addEmployee(Customer ee) {
		// TODO Auto-generated method stub
		CollectionUTIL.addEmp(ee);
		return ee.getPhone();
	}
	
	 

	    @Override
	    public Map<Integer,Customer> fetchAllEmp() {
	        
	        return CollectionUTIL.getAllEmp();
	    }
	
}
