package com.pw.es.util;


	



//	import java.time.LocalDate;
//import java.time.Month;
import java.util.*;

import com.pw.es.bean.Customer;
import com.pw.es.bean.PizzaOrder;
	public class CollectionUTIL 
	{
		static HashMap<Integer,Customer> map = new HashMap<Integer,Customer>();
		static HashMap<Integer,PizzaOrder> pzamap = new HashMap<Integer,PizzaOrder>();
		 static
		 
		{
			 PizzaOrder p1 = new  PizzaOrder(456,789,350.0);
			 PizzaOrder p2 = new  PizzaOrder(46,755,380.0);
			Customer e1 = new Customer ("Amita","Airoli","9898921546");
			Customer e2 = new Customer ("Raja","Mumbai","98236598746");
			Customer e3 = new Customer ("Mita","Nanu","2365921546");
			
		/*	
			Random r=new Random(10000);
			int id=r.nextInt();
			*/
			map.put((int)(Math.random()*1000),e1);
			map.put((int)(Math.random()*1000),e2);
			map.put((int)(Math.random()*1000),e3);
			
			
			
		}	
		public static void addEmp(Customer emp)
		{
			map.put((int) Math.random(),emp);
		}
		public  static HashMap<Integer, Customer> getAllEmp()
		{
			return map;
		}
	}



