package com.pw.es.bean;

public class PizzaOrder {
	
	private int orderId;
	private int customerId;
	private double totalprice;
	
	//constructor
	public PizzaOrder(int orderId, int customerId, double totalprice) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.totalprice = totalprice;
	}
	//getter and setter
	public int getOrderId() {
		return orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public double getTotalprice() {
		return totalprice;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	@Override
	public String toString() {
		return "PizzaOrder [orderId=" + orderId + ", customerId=" + customerId
				+ ", totalprice=" + totalprice + "]";
	}
	
	
	

}
