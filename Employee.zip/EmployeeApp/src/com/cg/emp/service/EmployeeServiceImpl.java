package com.cg.emp.service;

import java.util.List;

import com.cg.emp.dao.EmployeeDao;
import com.cg.emp.dao.EmployeeDaoImpl;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDao empDao=new EmployeeDaoImpl();

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		return empDao.getAllEmployees();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		return empDao.addEmployee(emp);
	}

}
