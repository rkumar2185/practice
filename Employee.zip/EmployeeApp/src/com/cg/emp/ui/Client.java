package com.cg.emp.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.service.EmployeeService;
import com.cg.emp.service.EmployeeServiceImpl;

public class Client {
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		int choice = 0;

		while (true) {
			System.out.println("1.Display Employees");
			System.out.println("2.Add an Employee");
			System.out.println("3.Exit");

			choice = scan.nextInt();
			switch (choice) {
			case 1:
				displayEmployees();
				break;
			case 2:
				addEmployee();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("INVALID CHOICE");
				break;
			}
		}
	}

	private static void addEmployee() {
		Employee emp = new Employee();
		System.out.println("Enter Employee Id");
		emp.setId(scan.nextInt());
		System.out.println("Enter Employee Name");
		emp.setName(scan.next());
		System.out.println("Enter Gender");
		emp.setGender(scan.next());
		System.out.println("Enter age");
		emp.setAge(scan.nextInt());
		System.out.println("Enter Salary");
		emp.setSalary(scan.nextDouble());
		EmployeeService service = new EmployeeServiceImpl();
		try {
			int result = service.addEmployee(emp);
			if (result != 1) {
				System.err.println("No Row Inserted");
			} else {
				System.out.println("Employee details saved");
			}
		} catch (EmployeeException e) {
			System.err.println("eRROR:" + e.getMessage());
		}

	}
	private static void displayEmployees() {
		EmployeeService service = new EmployeeServiceImpl();
		try {
			List<Employee> employees = service.getAllEmployees();
			for (Employee employee : employees) {
				System.out.println(employee);
			}
		} catch (EmployeeException e) {
			System.err.println("Error" + e.getMessage());
		}

	}

}
