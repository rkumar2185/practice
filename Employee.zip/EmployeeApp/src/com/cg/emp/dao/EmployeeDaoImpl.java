package com.cg.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		List<Employee> employees = new ArrayList<Employee>();
		Connection con = DBUtil.getConnection();
		try {
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from employee");
			while (rs.next()) {
				Employee emp = new Employee();
				emp.setId(rs.getInt(1));
				// emp.setId(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setGender(rs.getString(3));
				emp.setAge(rs.getInt(4));
				emp.setSalary(rs.getDouble(5));
				employees.add(emp);
			}
			return employees;
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		Connection con = DBUtil.getConnection();
		try {
			PreparedStatement stat = con.prepareStatement("insert into "
					+ "employee values(?,?,?,?,?)");
			stat.setInt(1, emp.getId());
			stat.setString(2, emp.getName());
            stat.setString(3, emp.getGender());
            stat.setInt(4, emp.getAge());
            stat.setDouble(5, emp.getSalary());
            
            return stat.executeUpdate();
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}

		//return 0;
	}

}
