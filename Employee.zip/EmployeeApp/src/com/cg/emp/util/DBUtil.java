package com.cg.emp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.emp.exception.EmployeeException;

public class DBUtil {
	public static Connection getConnection() throws EmployeeException {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		// for mysql--"jdbc:mysql://localhost/dbname"

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			return DriverManager.getConnection(url, "system", "root");
		} catch (ClassNotFoundException e) {
			throw new EmployeeException(e.getMessage());
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
	}

}
