package com.cg.productmgmt.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.dto.ProductRate;




public class DBUtil {
	static Map<String,String> productDetails;
	static Map<String,Integer> salesDetails;
	static{
		productDetails=new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "Paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");
		
		salesDetails=new HashMap<>();
		salesDetails.put("lux",100);
		salesDetails.put("colgate",50);
		salesDetails.put("pears",70);
		salesDetails.put("sony",10000);
		salesDetails.put("samsung",23000);
		salesDetails.put("facepack",100);
		salesDetails.put("facecream",60);
		
	}
	
	 public  static Map<String,Integer> getAllRate()
	    {
	        return salesDetails;
	    }
	 public  static Map<String,String> getAllType()
	    {
	        return productDetails;
	    }
	 public static void updateRate(String cat, String rate){
		 Map<String,String> temp = productDetails;
			Map<String,Integer> temp2 = salesDetails;
			for(Map.Entry<String, String> entry:temp.entrySet()){
				String str1 = entry.getKey();
				String str2 = entry.getValue();
				if(str2.equals(cat)){
					
					for(Map.Entry<String, Integer> entry2:temp2.entrySet()){
						if(str1.equals(entry2.getKey())){
						String str11 = entry2.getKey();
						int str21 = entry2.getValue();
						int qwe = Integer.parseInt(rate);
						int hike = qwe+str21;
						 salesDetails.replace(str11,hike);
						
						}
					}
					
					
				}
			}		 
	 }

}
