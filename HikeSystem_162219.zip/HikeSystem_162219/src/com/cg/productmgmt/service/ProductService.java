package com.cg.productmgmt.service;

import java.util.Iterator;
import java.util.Map;
import java.util.regex.Pattern;








import com.cg.productmgmt.dao.IProductDao;
import com.cg.productmgmt.dao.ProductDao;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService{
	static IProductDao proDao=null;
	public ProductService(){
		proDao=new ProductDao();
	}

	@Override
	public int updateProducts(String Category, int hike)
			throws ProductException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return proDao.getProductDetails();
	}

	
	@Override
	public boolean validateHike(String rate) throws ProductException {
		// TODO Auto-generated method stub
		String digitPatter="[1-9][0-9]*";
		if(Pattern.matches(digitPatter, rate))
		{
			return true;
		}
		else
		{
			throw new ProductException(" Invalid input \n"
					+ " Hike rate Should be Greater than Zero");
		}
	
		
	}

	@Override
	public boolean validateProduct(String cat) throws ProductException {
		// TODO Auto-generated method stub
		Map<String,String> temp=proDao.getProductCategory();
		Iterator it=temp.values().iterator();
		String str=null;
		while(it.hasNext())	
		{
			str=(String) it.next();
			if(str.equals(cat)){
				
				return true;
			}
		}
		
		throw new ProductException(" Category not found ");
	}

	@Override
	public void updateQuery(String cat, String rate) {
		proDao.update(cat, rate);
		
	}

	
}
