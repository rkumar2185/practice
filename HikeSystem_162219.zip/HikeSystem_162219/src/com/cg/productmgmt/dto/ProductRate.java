package com.cg.productmgmt.dto;

public class ProductRate {
	private int proRate;
    private String proCategory;
	public ProductRate(int proRate, String proCategory) {
		super();
		this.proRate = proRate;
		this.proCategory = proCategory;
	}
	public int getProRate() {
		return proRate;
	}
	public void setProRate(int proRate) {
		this.proRate = proRate;
	}
	public String getProCategory() {
		return proCategory;
	}
	public void setProCategory(String proCategory) {
		this.proCategory = proCategory;
	}
	@Override
	public String toString() {
		return "Product [proRate  " + proRate + ", proCategory  " + proCategory
				+ "]";
	}
    

}
