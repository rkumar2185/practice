package com.cg.productmgmt.dto;

public class ProductSale {
	private String proType;
    private String proCategory;
    
	public ProductSale(String proType, String proCategory) {
		super();
		this.proType = proType;
		this.proCategory = proCategory;
	}
	public String getProType() {
		return proType;
	}
	public void setProType(String proType) {
		this.proType = proType;
	}
	public String getProCategory() {
		return proCategory;
	}
	public void setProCategory(String proCategory) {
		this.proCategory = proCategory;
	}
    

}
