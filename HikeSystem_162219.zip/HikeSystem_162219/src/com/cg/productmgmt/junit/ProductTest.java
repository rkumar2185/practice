package com.cg.productmgmt.junit;

import java.time.LocalDate;

import junit.framework.Assert;

import org.junit.BeforeClass;



import org.junit.Test;



import com.cg.productmgmt.dao.IProductDao;
import com.cg.productmgmt.dao.ProductDao;
import com.cg.productmgmt.exception.ProductException;

public class ProductTest {
	static IProductDao testDao=null;
	 @BeforeClass
	    public static void setUp()
	    {
	        testDao=new ProductDao();
	    }
//	 @Test
//	    public void updateTest() throws ProductException
//	    {
//	        Assert.assertEquals(111, empdao.addEmployee(
//	                new Employee(111,"aaa",1111.0F,
//	                        LocalDate.now())));
//	    }
	 @Test
	 public void fetchAll() throws ProductException
	 {
		 Assert.assertNotNull(testDao.getProductDetails());
	 }

}
