package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.util.DBUtil;

public class ProductDao implements IProductDao{
	
	@Override
	public int updateProducts(String Category, int hike)
			throws ProductException {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return DBUtil.getAllRate();
	}
	public Map<String, String> getProductCategory() throws ProductException {
		// TODO Auto-generated method stub
		return DBUtil.getAllType();
	}
	@Override
	public void update(String cat, String rate) {
		// TODO Auto-generated method stub
		DBUtil.updateRate(cat, rate);
	}

}
