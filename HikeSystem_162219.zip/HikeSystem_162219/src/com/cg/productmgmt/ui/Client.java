package com.cg.productmgmt.ui;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;



import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;


public class Client {
	static Scanner sc=null;
	static IProductService saleService=null;
	public static void main(String [] args){
		saleService=new ProductService();

		// TODO Auto-generated method stub

		
		sc = new Scanner(System.in);
		int choice;
		while (true) {
			System.out.println("Welcome to Hike Desk");
			System.out.println("Press 1: Update Product Price");
			System.out.println("Press 2: Display Product List");
			
			System.out.println("Press 3: Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
			updateProduct();
				break;
			case 2:
				displayList();
				
				break;
			case 3:System.exit(0);
			default:
				System.out.println("!!!Please Enter a valid choice!!!");
			}
	}

}

	private static void displayList() {
		 
		Map<String, Integer> sDeatails;
		try {
			sDeatails = saleService.getProductDetails();
			Iterator<Map.Entry<String,Integer>> it = sDeatails.entrySet().iterator();
			  
	        System.out.println("---------------------------");  
	        System.out.println("Product Name\t\tPrice");     
	        while(it.hasNext())
	        {
	             Map.Entry<String,Integer> ee = it.next();
	            
	             System.out.println(ee);
	        }       
	        System.out.println("---------------------------");
			
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        
		
	}

	private static void updateProduct() {
		// TODO Auto-generated method stub
		System.out.println("Enter The Product Category :");
		String proCat=sc.next();
		try{
			if(saleService.validateProduct(proCat))
			{
				System.out.println("Enter Hike Rate :"); 
				String proRate=sc.next();
				try{
					if(saleService.validateHike(proRate)){
						saleService.updateQuery(proCat,proRate);
						System.out.println("Hike Rate Has Been Updated");
					}
				}
				catch(ProductException e)
				{
					System.out.println(e.getMessage()); 
				}
			}
		}
		catch(ProductException e)
		{
			System.out.println(e.getMessage()); 
		}
		
	}
}
	
