import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;


public class TestPropWriteDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileWriter fw = new FileWriter
					("compInf.propertieso");
			Properties compinfoProp = new Properties();
			compinfoProp.setProperty("compyname","capgemini");
			compinfoProp.setProperty("compylocat","mumabi");
			compinfoProp.setProperty("country","India");
			
			compinfoProp.store(fw, "this file contain company info");
			System.out.println("prop files is created");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
