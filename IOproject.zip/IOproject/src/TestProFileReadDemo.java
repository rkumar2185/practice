import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;


public class TestProFileReadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			FileReader fr = new FileReader("userinfo.properties");
			Properties props = new Properties();
			
				props.load(fr);
				
				String usr = props.getProperty("username");
				String pwd = props.getProperty("password");
				String loc = props.getProperty("location");
				
				System.out.println("username:" +usr + "Password:"+pwd + "location:"+loc);
				
				System.out.println("*************");
				//to retrieve all the data
				
				Set keySet = props.keySet();
				Iterator it = keySet.iterator();
				while(it.hasNext())
				{
					System.out.println((String)it.next()+ " ");
				}
				
		}
				catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		

	}

}
