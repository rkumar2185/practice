package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Login;
import com.cg.util.DBUTIL;

public class LoginDaoImpl {
     Connection con = null;
     PreparedStatement pst=null;
     ResultSet rs=null;
     Login usr= null;
     
     public LoginDaoImpl(){
    	super();
     }
     public Login getUserDetails(String unm)
    	 throws SQLException {
    	 con=DBUTIL.getCon();
    	 System.out.println("In dao get conne:"+con);
    	 String sql="SELECT * FROM LOGIN_TBL WHERE USER_NAME=?";
    	// try {
			pst=con.prepareStatement(sql);
			 pst.setString(1,unm);
			 rs=pst.executeQuery();
			 rs.next();
			 usr = new Login(rs.getString("USER_NAME"),rs.getString("USER_PASS"));
	//	} catch (SQLException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
	//	}
    	 return usr;
     }
}
