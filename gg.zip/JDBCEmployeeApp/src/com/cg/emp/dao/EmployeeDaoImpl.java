package com.cg.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.util.DbUtil;

public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public List<Employee> getAllEmployee() throws EmployeeException {
		/*List<Employee> employees = new ArrayList<Employee>();
		Connection con = DbUtil.getConnection();
		try {
			Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from Employee");
			while(rs.next()){
				Employee emp = new Employee();
				emp.setId(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setGender(rs.getString(3));
				emp.setAge(rs.getInt(4));
				emp.setSalary(rs.getDouble(5));
				employees.add(emp);
				
			}
			return employees;
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		*/
		EntityManager em=DbUtil.getEntityManager();
		String str="from Employee where gender=?";
		TypedQuery<Employee> query=em.createQuery(str, Employee.class);
		query.setParameter(1, "Male");
		return query.getResultList();
		
		
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		/*Connection con = DbUtil.getConnection();
		try {
			PreparedStatement stat = con.prepareStatement("insert into employee values(?,?,?,?,?)");
			stat.setInt(1, emp.getId());
			stat.setString(2, emp.getName());
			stat.setString(3,emp.getGender());
			stat.setInt(4,emp.getAge());
			stat.setDouble(5, emp.getSalary());
			return stat.executeUpdate();
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
		*/
		try{
		
		EntityManager em=DbUtil.getEntityManager();
		em.getTransaction().begin();
		em.persist(emp);
		
		em.getTransaction().commit();
		return 1;
		}
		catch(Exception e){
			throw new EmployeeException(e.getMessage());
		}
	}

}
