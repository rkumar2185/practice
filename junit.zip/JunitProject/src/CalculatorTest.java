import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class CalculatorTest {
	static Calculator calc = null;
	
	@BeforeClass
	public static  void setUp()
	{
		calc = new  Calculator();
		System.out.println("this function is called once"
	           +"before the execution of all tets cases");
	}
	@Before
	public  void init()
	{
		System.out.println("this function is called "
	           +"before the execution of each tets cases");
	}
	
	
	@After
	public void destroy()
	{
		System.out.println("this function is called "
		           +"after the execution of each tets cases");
	}
	@AfterClass
	public static void tearDown()
	{
		System.out.println("this function is called once"
		           +"after the execution of all tets cases");
	}
	
	@Test
	public void divideTest1()
	{
		Assert.assertEquals(4, calc.divide(25));
	}
	@Test
	public void divideTest2()
	{
		Assert.assertEquals(2, calc.divide(50));
	}
	@Test(expected=ArithmeticException.class)
	public void divideTest3()
	{
		Assert.assertEquals(1, calc.divide(0));
	}
	@Test
	public void divideTest4()
	{
		Assert.assertEquals(1, calc.divide(100));
	}
	
	

}
