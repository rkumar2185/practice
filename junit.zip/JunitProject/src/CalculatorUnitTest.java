import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class CalculatorUnitTest {

	private int input;
	private int expected;

	@Parameterized.Parameters
	public static Collection data() {
		return Arrays.asList(new Object[][] { { 25, 4 }, { 100, 1 }, { 50, 2 },
				{ 10, 10 }, { 5, 20 } });
	}

	public CalculatorUnitTest(int input, int expected) {
		super();
		this.input = input;
		this.expected = expected;
	}

	@Test//(expected = ArithmeticException.class)
	public void testMethod() {
		//
		Assert.assertEquals(expected, Calculator.divide(input));

	}
}
