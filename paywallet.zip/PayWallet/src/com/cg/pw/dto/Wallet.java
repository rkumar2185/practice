package com.cg.pw.dto;

public class Wallet {

	private double balance;

	public Wallet() {
	}

	public Wallet(double balance) {
		super();
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}

}
