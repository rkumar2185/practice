package com.cg.pw.service;

import java.util.HashMap;

import com.cg.pw.dao.WalletDao;
import com.cg.pw.dao.WalletDaoImpl;
import com.cg.pw.dto.Customer;
import com.cg.pw.exception.CustomerException;

public class WalletServiceImpl implements WalletService {
	WalletDao wdao = new WalletDaoImpl();

	public Customer createAccount(Customer customer) {
		return wdao.createAccount(customer);
	}

	public double showBalance(String mobileno) throws CustomerException {
		return wdao.showBalance(mobileno);
	}

	public double deposit(String mobileno, double amount)
			throws CustomerException {
		return wdao.deposit(mobileno, amount);
	}

	public double withdraw(String mobileno, double amount)
			throws CustomerException {
		return wdao.withdraw(mobileno, amount);
	}

	public Customer transfer(String mob_from, String mob_to, double amount)
			throws CustomerException {
		return wdao.transfer(mob_from, mob_to, amount);
	}

	public HashMap<Integer, String> printTransactions()
			throws CustomerException {
		return wdao.printTransactions();
	}

	public boolean validateCustomer(Customer cust) throws CustomerException {
		if(!cust.getName().matches("[A-Za-z]{1,50}")){
			throw new CustomerException("ERROR: Your name should be alphabetical in natre and less than 50 characters long");
		}
		if(!cust.getMobileno().matches("[0-9]{10}")){
			throw new CustomerException("Error: your mobile number contain 10 digit number");
		}
		if(cust.getWallet().getBalance()<0){
			throw new CustomerException("Could not contain negative intial value");
		}else{
		return true;
		}
	}

}


/*if (!customer.getName().matches("[A-Za-z ]{1,50}")) {
	throw new CustomerExceptions("ERROR: Your name should be alphabetical in nature and less than 50 characters long.");
}
if (!customer.getMobileno().matches("[0-9]{10}")) {
	throw new CustomerExceptions("ERROR: Your mobile number must be numerical and 10 digits long.");
}
if (customer.getWallet().getBalance()<0) {
	throw new CustomerExceptions("ERROR: Please enter a non-negative initial balance.");
} else {
	return true;
}*/
