package com.cg.pw.service;

import java.util.HashMap;

import com.cg.pw.dto.Customer;
import com.cg.pw.exception.CustomerException;

public interface WalletService {
	Customer createAccount(Customer customer);

	double showBalance(String mobileno) throws CustomerException;

	double deposit(String mobileno, double amount) throws CustomerException;

	double withdraw(String mobileno, double amount) throws CustomerException;

	Customer transfer(String mob_from, String mob_to, double amount)
			throws CustomerException;

	HashMap<Integer, String> printTransactions() throws CustomerException;

	boolean validateCustomer(Customer cust) throws CustomerException;

}
