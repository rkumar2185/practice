package com.cg.pw.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pw.dto.Customer;
import com.cg.pw.dto.Wallet;
import com.cg.pw.exception.CustomerException;

public class WalletDaoImpl implements WalletDao{
	//Database stored the customer identfied by their mobileno
	Map<String,Customer> database = new HashMap<String ,Customer>();
	public WalletDaoImpl(){
		//createing three base accounts for reference
		Customer ravi = new Customer("Ravi Kumar","9876543219",new Wallet(500.0));
		Customer raj = new Customer("Raj Kumar","9876543210",new Wallet(300.0));
		Customer rani = new Customer("Rani Kumari","9876543211",new Wallet(600.0));
		database.put(ravi.getMobileno(),ravi);
		database.put(raj.getMobileno(),raj);
		database.put(rani.getMobileno(),rani);
	}

	public Customer createAccount(Customer customer) {
		//adds new customer to database
		database.put(customer.getMobileno(), customer);
		return customer;
	}

	public double showBalance(String mobileno) throws CustomerException {
	//identifies mobileno and print  wallet balance 
		if(database.containsKey(mobileno))
		return database.get(mobileno).getWallet().getBalance() ;
		else 
			throw new CustomerException("Error:Account Not found");
	}

	public double deposit(String mobileno, double amount)
			throws CustomerException {
		if(database.containsKey(mobileno))
		{
			if(amount>0)
			{
				double bal = database.get(mobileno).getWallet().getBalance();
				bal = bal+amount;
				
			}
			return  ;
		}
		else
			throw new CustomerException("Error: Account Not found");
		
	}

	public double withdraw(String mobileno, double amount)
			throws CustomerException {
		return 0;
	}

	public Customer transfer(String mob_from, String mob_to, double amount)
			throws CustomerException {
		return null;
	}

	public HashMap<Integer, String> printTransactions()
			throws CustomerException {
		// TODO Auto-generated method stub
		return null;
	}

}
