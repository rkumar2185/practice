package com.cg.pw.ui;

import java.util.Scanner;

import com.cg.pw.dto.Customer;
import com.cg.pw.dto.Wallet;
import com.cg.pw.exception.CustomerException;
import com.cg.pw.service.WalletService;
import com.cg.pw.service.WalletServiceImpl;

public class Client {

	public static void main(String[] args) {
		WalletService wser = new WalletServiceImpl();

		String name, mobileno;
		double balance, amount;
		System.out.println("***WELCOME TO THE WORLD OF DIGITAL***");

		System.out
				.println("Menu \n1. Create Account \n2. Show balance \n3. Add balance \n4. Withdraw money \n5. Send money \n6. Transaction history \n7. Exit");
		System.out.println("Enter your choice");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			System.out.println("Enter Your Name (First Name space Last Name) ");
			String firstname = sc.next();
			String lastname = sc.next();
			name = firstname + " " + lastname;

			System.out.println("Enter your mobile number");
			mobileno = sc.next();

			System.out.println("Intial amount to b filled");
			balance = sc.nextDouble();

			Customer cust = new Customer(lastname, mobileno,
					new Wallet(balance));
			try {
				if (wser.validateCustomer(cust)) {
					System.out.println("Account Created " + "\nDetails:"
							+ wser.createAccount(cust));
				} else
					break;
			} catch (CustomerException e) {
				System.out.println(e.getMessage());
				break;
			}

			break;
		case 2:
			System.out.println("Enter your mobileno");
			mobileno = sc.next();

			try {
				System.out.println("Your Current Balance : " + " "
						+ wser.showBalance(mobileno));
			} catch (CustomerException e) {
				System.out.println(e.getMessage());
			}

			break;
		case 3:
			System.out.println("Enter your mobileno");
			mobileno = sc.next();

			System.out.println("Enter amount to add");
			amount = sc.nextDouble();

			try {
				wser.deposit(mobileno, amount);
				System.out.println(""+amount+"successfully added in your account");
			} catch (CustomerException e) {
                 System.out.println(e.getMessage());
			}

			break;
		case 4:

			break;
		case 5:

			break;
		case 6:

			break;
		case 7:

			break;

		default:
			break;
		}

	}

}
