package com.cg.es.ui;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import com.cg.es.dto.Employee;
import com.cg.es.exception.EmployeeException;
import com.cg.es.service.EmpService;
import com.cg.es.service.EmpServiceImpl;

public class TestEmpClient {
    
    static EmpService empSer = null;
    static Scanner sc = null;
    
    public static void main(String[] args) {
        empSer = new EmpServiceImpl();
        sc = new Scanner(System.in);
        int choice;
        while(true){
        	System.out.println("\n");
            System.out.println("*******WOW we have an option...lets do it********");
            System.out.println("\n");
            System.out.println("1. Add Emp\t\t2. Get All Emp Info");
            System.out.println("3. Update Emp\t\t4. Search Emp By Id");
            System.out.println("5. Search Emp By Name\t6. Delete Emp Info");
            System.out.println("7. Exit");
            System.out.println("*******************************");
            System.out.println("Whats your Path number: ");
            choice = sc.nextInt();
            performOperation(choice);
        }

    }

    private static void performOperation(int choice) {

        switch(choice){
        case 1: addEmp();
            break;
        case 2:showEmpInfo();
            break;
        case 3:updateEmpInfo();
            break;
        case 4:serById();
            break;
        case 5:serByName();
            break;
        case 6:delEmp();
            break;
        default:System.exit(0);
        }
        
    }

    private static void updateEmpInfo() {
        System.out.println("Please Enter Employee Favourite Id: ");
        int eId = sc.nextInt();
        int f = empSer.updateEmp(eId);
        if(f==1){
            System.out.println("You are Indeed Correct Data Sucessfully Updated");
            System.out.println(":)");
        }
        else{
            System.out.println("Don't lose your hope ...:) let's try once ::)");
        }   
        
    }

    private static void delEmp() {
        System.out.println("Please Enter Employee Id: ");
        int eId = sc.nextInt();
        int f = empSer.deleteEmp(eId);
        if(f==1){
            System.out.println("yeeehhh! Data deleted");
        }
        else{
            System.out.println("Don't lose your hope ...:) let's try once :");
        }
        
    }

    private static void serByName() {
        while(true){
            System.out.println("Hey ,Do you know Employee Name?:  if yes please mention :)");
            String eName = sc.next();
            try{
                if(empSer.validateName(eName)){
                    Map<Integer,Employee> ttt = empSer.searchEmpName(eName);
                    Iterator<Employee> itMap = ttt.values().iterator();
                    Employee srch = null;
                
                        while(itMap.hasNext()){
                            srch = (Employee) itMap.next();
                        System.out.println("Employee [empId=" + srch.getEmpId() 
                                + ", empname=" + srch.getEmpname()+ ", empSal=" 
                                + srch.getEmpSal() + ", empDOJ=" + srch.getEmpDOJ()+"]");
                        }
                        break;
                    
                    
                }
            }catch(EmployeeException e){
                e.getMessage();
            }
        }
    }

    private static void serById() {
        while(true){
            System.out.println("Enter Employee Id: ");
            String eId = sc.next();
            try{
                if(empSer.validateInt(eId)){
                    Employee srch = empSer.searchEmpId(Integer.parseInt(eId));
                    if(srch!=null){
                        System.out.println("Employee [empId=" + srch.getEmpId() 
                                + ", empname=" + srch.getEmpname()+ ", empSal=" 
                                + srch.getEmpSal() + ", empDOJ=" + srch.getEmpDOJ()+"]");
                        break;
                    }
                    else{
                        System.out.println("Don't lose your hope ...:) let's try once :.");
                    }
                
                }
            }catch(EmployeeException e){
                System.out.println(e.getMessage());
            }
        }
        
    }

    private static void showEmpInfo() {
        /*Set<Employee> emps = empSer.fetchAllEmp();*/
        Map<Integer,Employee> emps = empSer.fetchAllEmp();
        /*Iterator<Employee> it = emps.iterator();*/
        Iterator<Employee> it = emps.values().iterator();
        while(it.hasNext()){
            Employee temp = it.next();
            System.out.println("Employee [empId=" + temp.getEmpId() 
                    + ", empname=" + temp.getEmpname()+ ", empSal=" 
                    + temp.getEmpSal() + ", empDOJ=" + temp.getEmpDOJ()+"]");
        }
        
    }

    private static void addEmp() {
        while(true){
            System.out.println("Enter Emp Id: ");
            String eId = sc.next();
            try {
                if(empSer.validateInt(eId)){    
                    System.out.println("Enter Emp Name: ");
                    String eName = sc.next();
                    try{
                        if(empSer.validateName(eName)){
                            System.out.println("This is my fav , Enter Emp Salary: ");
                            String eSal = sc.next();
                            try{
                                if(empSer.validateInt(eSal)){
                                    Employee ee = new Employee(Integer.parseInt(eId),eName,Float.parseFloat(eSal),LocalDate.now());
                                    int f = empSer.addEmployee(ee);
                                    if(f==1){
                                        System.out.println("You are lucky , its Added Successfully.");
                                        break;
                                    }
                                    else if(f==0){
                                        System.out.println("oos! Some Error Occured. ");
                                    }
                                }
                            }catch(EmployeeException e){
                                System.out.println(e.getMessage());
                            }
                        }
                    }catch(EmployeeException e){
                        System.out.println(e.getMessage());
                    }
                }
            } catch(EmployeeException e){
                System.out.println(e.getMessage());
            }
        }
    }
}