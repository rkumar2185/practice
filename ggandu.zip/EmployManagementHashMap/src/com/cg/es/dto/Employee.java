package com.cg.es.dto;


import java.time.LocalDate;

public class Employee{
    private int empId;
    private String empname;
    private float empSal;
    private LocalDate empDOJ;
    public Employee(int empId, String empname, float empSal, LocalDate empDOJ) {
        super();
        this.empId = empId;
        this.empname = empname;
        this.empSal = empSal;
        this.empDOJ = empDOJ;
    }
    public int getEmpId() {
        return empId;
    }
    public void setEmpId(int empId) {
        this.empId = empId;
    }
    public String getEmpname() {
        return empname;
    }
    public void setEmpname(String empname) {
        this.empname = empname;
    }
    public float getEmpSal() {
        return empSal;
    }
    public void setEmpSal(float empSal) {
        this.empSal = empSal;
    }
    public LocalDate getEmpDOJ() {
        return empDOJ;
    }
    public void setEmpDOJ(LocalDate empDOJ) {
        this.empDOJ = empDOJ;
    }
    @Override
    public String toString() {
        return "Employee [empId=" + empId + ", empname=" + empname
                + ", empSal=" + empSal + ", empDOJ=" + empDOJ + "]";
    }
    
    
}