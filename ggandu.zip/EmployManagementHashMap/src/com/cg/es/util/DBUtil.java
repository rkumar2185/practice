package com.cg.es.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;

import java.util.Map;


import com.cg.es.dto.Employee;

public class DBUtil{
    
    static int s=5;
    public static HashMap<Integer,Employee> empMap = new HashMap<Integer,Employee>();
    static{
        empMap.put(1,(new Employee(100,"Lovely",80000,LocalDate.of(1996, Month.MAY,23))));
        empMap.put(2,(new Employee(101,"Singh",90000,LocalDate.of(1998, Month.JANUARY, 03))));
        empMap.put(3,(new Employee(102,"Dreamji",16000,LocalDate.of(1997, Month.JULY,22))));
        empMap.put(4,(new Employee(103,"Sapnaji",57000,LocalDate.of(1997, Month.FEBRUARY,22))));
    }
    public static void addEmployee(Employee ee){
    	empMap.put(s++,ee);
        
    }
    public static Map<Integer,Employee> getAllEmp(){
        return empMap;
    }}

