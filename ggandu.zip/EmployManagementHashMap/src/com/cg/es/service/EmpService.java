package com.cg.es.service;

import java.util.Map;
import com.cg.es.dto.Employee;
import com.cg.es.exception.EmployeeException;

public interface EmpService {
    public int addEmployee(Employee ee);
    
    public Map<Integer,Employee> fetchAllEmp();
    public Employee searchEmpId(int eId);
    public Map<Integer,Employee> searchEmpName(String eName);
    public int deleteEmp(int eId);
    public int updateEmp(int eId);
    public boolean validateName(String eName)throws EmployeeException ;
    public boolean validateInt(String eId) throws EmployeeException ;
    public boolean validateDate(String date)throws EmployeeException ;
    
}