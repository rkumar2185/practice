package com.cg.es.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.es.exception.EmployeeException;
/*import java.util.Set;*/
import co.cg.es.dao.EmpDaoImpl;
import co.cg.es.dao.EmployeeDao;
import com.cg.es.dto.Employee;


public class EmpServiceImpl implements EmpService{
    EmployeeDao empDao = null;
    
    public EmpServiceImpl(){
        empDao = new EmpDaoImpl();
    }
    @Override
    public int addEmployee(Employee ee) {
        return empDao.addEmployee(ee);
    }

    @Override
    /*public Set<Employee> fetchAllEmp() {
        return empDao.fetchAllEmp();
    }*/
    public Map<Integer,Employee> fetchAllEmp() {
        return empDao.fetchAllEmp();
    }

    @Override
    public Employee searchEmpId(int eId) {
        return empDao.searchEmpId(eId);
    }

    @Override
    public Map<Integer,Employee> searchEmpName(String eName) {
        return empDao.searchEmpName(eName);
    }

    @Override
    public int deleteEmp(int eId) {
        return empDao.deleteEmp(eId);
    }

    @Override
    public int updateEmp(int eId) {
        return empDao.updateEmp(eId);
    }

    @Override
    public boolean validateName(String eName) throws EmployeeException {
        // TODO Auto-generated method stub
        String myPattern = "[A-Z][a-z]+";
        if(Pattern.matches( myPattern,eName)){
            return true;
        }
        else {
            throw new EmployeeException(" OOOHHH!  Invalid input , Sorry  "
                + " Only Char are  allowed  and should start"
                + " with Capital ex.Lovely  :)");
        }
    }
    
        
    

    @Override
    public boolean validateInt(String eId) throws EmployeeException{
        String myPattern = "[0-9]+";
        if(Pattern.matches(myPattern, eId)){
            return true;
        }
        else{
            throw new EmployeeException("Invalid input Only Integer Value is valued"
                    + "ex.  1452");
        }
    }

    @Override
    public boolean validateDate(String date) throws EmployeeException {
        DateTimeFormatter dte = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        if(LocalDate.parse(date, dte) != null){
        return true;
        }
        else{
            throw new EmployeeException("Format Error");
        }
    }
    
    }