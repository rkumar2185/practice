
package co.cg.es.dao;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import com.cg.es.dto.Employee;
import com.cg.es.util.DBUtil;

public class EmpDaoImpl implements EmployeeDao{
    Scanner sc = null;
    @Override
    public int addEmployee(Employee ee) {
    	DBUtil.addEmployee(ee);
        return ee.getEmpId();
    }

    @Override
    public Map<Integer,Employee> fetchAllEmp() {
        
        return DBUtil.getAllEmp();
    }

    @Override
    public Employee searchEmpId(int eId) {
        Map<Integer,Employee> emps = DBUtil.getAllEmp();
        Iterator<Employee> it =emps.values().iterator();
        while(it.hasNext()){
            Employee temp = it.next();
            if(temp.getEmpId() == eId){
                return temp;
            }
        }
        return null;
    }

    @Override
    public Map<Integer,Employee> searchEmpName(String eName) {
        int k=0;
        Map<Integer,Employee> emps =  DBUtil.getAllEmp();
        Map<Integer,Employee> tempMp = new HashMap<Integer,Employee>();
        Iterator<Employee> it = emps.values().iterator();
        while(it.hasNext()){
            Employee temp = it.next();
            if(temp.getEmpname().equals(eName)){
                tempMp.put(k++, temp);
            }
        }
        return tempMp;
    }

    @Override
    public int deleteEmp(int eId) {
    int f=0;
        Map<Integer,Employee> emps = DBUtil.getAllEmp();
        Iterator<Employee> itSet = emps.values().iterator();
        
        while(itSet.hasNext()){
            
            Employee temp = itSet.next();
            if( ((Employee) temp).getEmpId()==eId){
                itSet.remove();
                f=1;
            }
        }
        return f;
    }

    @SuppressWarnings("resource")
    @Override
    public int updateEmp(int eId) {
    
        
        /*
        Map<Integer,Employee> emps = DBUtil.getAllEmp();
        Iterator<Map.Entry<Integer,Employee>> itSet = emps.entrySet().iterator();
        while(itSet.hasNext()){
            Map.Entry<Integer, Employee>tempEmp = (Employee) itSet.next();
            if( tempEmp.getEmpId() == eId){
                Scanner sc = new Scanner(System.in);
                System.out.println("Enter the you want to update: ");
                String str = sc.next();
                tempEmp.setEmpname(str);
                System.out.println("Enter the updated salary: ");
                float slry = sc.nextFloat();
                tempEmp.setEmpSal(slry);
                sc.close();
                return 1;
            }
        }*/
        
        Map<Integer,Employee> emps = DBUtil.getAllEmp();
        Iterator<Employee> it = emps.values().iterator();
        Employee tempEmp = null;
        while(it.hasNext()){
            tempEmp = it.next();
            if(tempEmp.getEmpId() == eId){
                Scanner sc = new Scanner(System.in);
                System.out.println("Enter the you want to update: ");
                String str = sc.next();
                tempEmp.setEmpname(str);
                System.out.println("Enter the updated salary: ");
                float slry = sc.nextFloat();
                tempEmp.setEmpSal(slry);
                
                return 1;
            }
        }
         return 0;
    }

        
}
    

