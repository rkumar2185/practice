package co.cg.es.dao;

import java.util.Map;




import com.cg.es.dto.Employee;

public interface EmployeeDao {
    public int addEmployee (Employee ee);
    public Map<Integer,Employee> fetchAllEmp();

    public Employee searchEmpId(int eId);
    public Map<Integer,Employee> searchEmpName(String eName);
    public int deleteEmp(int eId);
    public int updateEmp(int eId);
    
}
