package co.cg.es.junit;

import static org.junit.Assert.*;

import java.time.LocalDate;




import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.es.dto.Employee;
import com.cg.es.exception.EmployeeException;

import co.cg.es.dao.EmpDaoImpl;

public class EmployeeDaoImplTest {
	static EmpDaoImpl empdao = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		empdao = new EmpDaoImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("this function is called once"
		           +"after the execution of all tets cases");
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void addEmpTest() throws EmployeeException {
		Assert.assertEquals(111, empdao.addEmployee(new Employee(111, "aaa",
				1111.0F, LocalDate.now())));
	}
	
	@Test
	public void testfetchAllEmp()
	{
		Assert.assertNotNull(empdao.fetchAllEmp());
	}


}
