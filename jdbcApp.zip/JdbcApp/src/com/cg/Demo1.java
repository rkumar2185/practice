
	
	//we need to accept the details
	package com.cg;

	import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

	//import com.mysql.jdbc.PreparedStatement;

	//import com.mysql.jdbc.Connection;

	public class Demo1 {
		public static void main(String[] args) {
			
		
		Scanner sc = new Scanner(System.in);
		
		//String url = "jdbc:mysql://localhost/gupta";
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con =DriverManager.getConnection(url,"system","root");
		System.out.println("Enter Employee Id");
		int id = sc.nextInt();
		//calling procedure
		CallableStatement stat = con.prepareCall("{call getEmployeeId(?,?)}");
		stat.setInt(1,id);
        stat.registerOutParameter(2, Types.VARCHAR); 
        stat.execute();
        String name=stat.getString(2);
        System.out.println("Name of the employee with id"+ id +"="+name);
	   /* ResultSet rs = stat.executeQuery();
		while(rs.next()){
			System.out.println(rs.getInt(1)+ "\t " + rs.getString(2)+
					"\t"+rs.getString(3)+"\t"+rs.getInt("age")
					+"\t"+rs.getDouble("salary"));
		}
		con.close();//connection should be clo
	*/	} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}



