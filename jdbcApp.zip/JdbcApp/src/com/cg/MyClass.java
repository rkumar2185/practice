package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyClass {
	
	public static void main(String[] args) {
		//need complete url to establis connection
		//DRIVER INFO  jdbc:mysql
		//running in ur lapy //localhost
		
		
		String url = "jdbc:mysql://localhost/gupta";
		
		try {
			
			//register and load the driver using this line of code
		
			Class.forName("com.mysql.jdbc.Driver");//instaed of using this
			
			
			
			
			// loading the driver is option from java 4
			// but we generally use may b client have old version so better to write tis 
			//line
		//	DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			
			//ESTABLISH CONNECTION
			//provide username and password
			Connection con =DriverManager.getConnection(url, "root","root");
			
			//creating statement
			Statement stat = con.createStatement();
			
			//execute the query
			ResultSet rs = stat.executeQuery("select * from employee");
			//for executing each line
			//rs.getInt(coloumn index)
			while(rs.next()){
				System.out.println(rs.getInt(1)+ "\t " + rs.getString(2)+
						"\t"+rs.getString(3)+"\t"+rs.getInt("age")
						+"\t"+rs.getDouble("salary"));
				
			}
			
		} 
		catch (SQLException e) {
			System.out.println("Error"+ e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}



