package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

public class Demo3 {
	public static void main(String[] args) {
		String url="jdbc:oracle:thin:@localhost:1522:XE";
		Connection con= null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con =DriverManager.getConnection(url,"system","root");
			con.setAutoCommit(false);
			PreparedStatement stat1 =con.prepareStatement("Update accounts set balance = balance+1000 where acccount id=110202");
					PreparedStatement stat3 =con.prepareStatement("delete accounts where  "+
				"	acccount id=110202");
					PreparedStatement stat2 =con.prepareStatement("update accounts set balance = balance+10000 where "+
							"	acccount id=110202");
					PreparedStatement stat4 =con.prepareStatement("delete accounts  where "+
							"	acccount id=110202");
                    stat1.executeUpdate();
					stat2.executeUpdate();
					Savepoint sp1=con.setSavepoint();
					stat3.executeUpdate();
					Savepoint sp2=con.setSavepoint();
					stat4.executeUpdate();
					con.commit();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}

}
