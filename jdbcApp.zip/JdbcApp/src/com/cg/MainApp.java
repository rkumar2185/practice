package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.Scanner;

//import com.mysql.jdbc.PreparedStatement;

public class MainApp {

	public static void main(String[] args) {
		/*//need complete url to establis connection
		//DRIVER INFO  jbdc:oracle:thin
		//running in ur lapy @localhost
		//if want another one 
		// PORT NUMBER  1521
		
		
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		
		try {
			
			//register and load the driver using this line of code
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//ESTABLISH CONNECTION
			//provide username and password
			Connection con =DriverManager.getConnection(url, "ravi","passwrd");
			
			//creating statement
			Statement stat = con.createStatement();
			
			//execute the query
			ResultSet rs = stat.executeQuery("select * from employeee");
			//for executing each line
			//rs.getInt(coloumn index)
			while(rs.next()){
				System.out.println(rs.getInt(1)+ "\t " + rs.getString(2)+
						"\t"+rs.getString(3)+"\t"+rs.getInt("age")
						+"\t"+rs.getDouble("salary"));
				
			}
			
		} catch (ClassNotFoundException e) {
			System.out.println("Error"+ e.getMessage());
		} catch (SQLException e) {
			System.out.println("Error"+ e.getMessage());
		}

	}
*/       
		Scanner scan = new Scanner(System.in);
		//String url="jdbc:oracle:thin:@localhost:1521:XE";//oracle
		String url="jdbc:mysql://localhost/gupta";//mysql
	//	String url ="jdbc:sqlserver://localhost:1433;databaseName=mydb";//Microsoft sql
	
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
				Class.forName("com.mysql.jdbc.Driver");
			Connection con =DriverManager.getConnection(url,"root","root");
			System.out.println("Enter gender");
			String gender =scan.nextLine();
			
			PreparedStatement stat =con.prepareStatement("select * from"
					+ " employee where gender=?");
			stat.setString(1, gender);
			
			ResultSet rs = stat.executeQuery();
			while(rs.next()){
				System.out.println(rs.getInt(1)+ "\t " + rs.getString(2)+
						"\t"+rs.getString(3)+"\t"+rs.getInt("age")
						+"\t"+rs.getDouble("salary"));
			}
			con.close();//connection should be close
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

		
}
}
