//we need to accept the details
package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//import com.mysql.jdbc.PreparedStatement;

//import com.mysql.jdbc.Connection;

public class Democlass1 {
	public static void main(String[] args) {
		
	
	Scanner sc = new Scanner(System.in);
	
	String url = "jdbc:mysql://localhost/gupta";
	try {
		Class.forName("com.mysql.jdbc.Driver");
	Connection con =DriverManager.getConnection(url,"root","root");
	System.out.println("Enter Employee Id");
	int id = sc.nextInt();

	System.out.println("Enter Amount");
	double amt = sc.nextDouble();
	
	PreparedStatement stat = con.prepareStatement("update employee set salary = salary+? where eno=?");
	stat.setDouble(1, amt);
	stat.setInt(2,id);
	int result=stat.executeUpdate();
	System.out.println(result+"salary is updated");

	
 	//substitute the value
	
	/*check tis code
	
	stat.setInt(1, id);
	stat.setString(2, empName);
	stat.setString(3,gender);
	stat.setInt(4, age);
    stat.setDouble(5, sal);	
    
    int result = stat.executeUpdate();
    System.out.println(result + "rows inserted into data base");*/
    con.close();
    
   /* ResultSet rs = stat.executeQuery();
	while(rs.next()){
		System.out.println(rs.getInt(1)+ "\t " + rs.getString(2)+
				"\t"+rs.getString(3)+"\t"+rs.getInt("age")
				+"\t"+rs.getDouble("salary"));
	}
	con.close();//connection should be clo
*/	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
