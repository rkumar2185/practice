//we need to accept the details
package com.cg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//import com.mysql.jdbc.PreparedStatement;

//import com.mysql.jdbc.Connection;

public class DemoClass {
	public static void main(String[] args) {
		
	
	Scanner sc = new Scanner(System.in);
	
	String url = "jdbc:mysql://localhost/gupta";
	try {
		Class.forName("com.mysql.jdbc.Driver");
	Connection con =DriverManager.getConnection(url,"root","root");
	System.out.println("Enter Employee Id");
	int id = sc.nextInt();
	System.out.println("Enter Name");
	String empName = sc.next();
	System.out.println("Enter Gender");
	String gender = sc.next();
	System.out.println("Age");
	int age = sc.nextInt();
	System.out.println("Enter Salary");
	double sal = sc.nextDouble();
	
	PreparedStatement stat = con.prepareStatement("insert into employee values(?,?,?,?,?)");
	//substitute the value
	stat.setInt(1, id);
	stat.setString(2, empName);
	stat.setString(3,gender);
	stat.setInt(4, age);
    stat.setDouble(5, sal);	
    
    int result = stat.executeUpdate();
    System.out.println(result + "rows inserted into data base");
    con.close();
    
   /* ResultSet rs = stat.executeQuery();
	while(rs.next()){
		System.out.println(rs.getInt(1)+ "\t " + rs.getString(2)+
				"\t"+rs.getString(3)+"\t"+rs.getInt("age")
				+"\t"+rs.getDouble("salary"));
	}
	con.close();//connection should be clo
*/	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
