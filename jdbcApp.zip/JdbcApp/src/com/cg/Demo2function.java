package com.cg;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

//import com.mysql.jdbc.PreparedStatement;

//import com.mysql.jdbc.Connection;

public class Demo2function {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		// String url = "jdbc:mysql://localhost/gupta";
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection(url, "system", "root");
			System.out.println("Enter Employee Id");
			int id = sc.nextInt();
			// calling procedure
			CallableStatement stat = con
					.prepareCall("{?=call getEmpSalary(?)}");
			stat.setInt(2, id);
			stat.registerOutParameter(1, Types.NUMERIC);
			stat.execute();
			double sal = stat.getDouble(1);
		//	String name = stat.getString(2);
			System.out
					.println("Salary of employee with id" + id + "=" + sal);

			con.close();// connection should be clo
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
