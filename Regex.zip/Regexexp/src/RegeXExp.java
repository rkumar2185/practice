import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RegeXExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String inpstr = "Test string";
		String pattrn = "Test string";
		
		boolean pattrnMatc = Pattern.matches(pattrn, inpstr);
		System.out.println(pattrnMatc);
		
		String input = "Shop, Mop,Hopping,Chopping";
		Pattern pattern =Pattern.compile("hop");
		Matcher matcher = pattern.matcher(input);
		System.out.println(matcher.matches());
		
		while(matcher.find())
		{
			System.out.println(matcher.group()+":"+matcher.start()+":"+matcher.end());
		}
		Scanner sc= new Scanner(System.in);
		System.out.println("********Ur Lovely Name***********");
		String firstName = sc.next();
		String fnPattern ="[A-Z][a-z]+";//+ one more occurance
		if(Pattern.matches(fnPattern, firstName))
		{
			System.out.println("Valid firstName");
		}
		else
		{
			System.out.println("Invalid!!!!!!!!"+"allowed should start with capital char");
		}
		

	}

}
