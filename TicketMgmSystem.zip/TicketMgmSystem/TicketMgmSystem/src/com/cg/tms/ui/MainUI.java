package com.cg.tms.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {

	static Scanner sc = null;
	static TicketService tcktSer = null;;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		tcktSer = new TicketServiceImpl();
		sc = new Scanner(System.in);
		int choice;
		while (true) {
			System.out.println("Welcome to ITIMD Help Desk");
			System.out.println("1. Raise a Ticket");
			System.out.println("2. Exit from the system");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				raiseTicket();
				break;
			case 2:
				System.exit(0);
				;
				break;
			default:
				System.out.println("!!!Please Enter a valid choice!!!");
			}
		}

	}

	private static void raiseTicket() {
		// TODO Auto-generated method stub
		BufferedReader buffer = new BufferedReader(new InputStreamReader(
				System.in));
		String tcktDescription;
		String choiceCategory = null;
		String choicePriority = null;
		int i = 1;
		System.out.println("Select Ticket Category from below List:");
		List<TicketCategory> tcktCateg = tcktSer.listTicketCategory();
		Iterator<TicketCategory> it = tcktCateg.iterator();
		while (it.hasNext()) {
			System.out.println((i++) + ". " + it.next().getCategoryName());
		}
		System.out.print("Enter option:");
		int choiceCat = sc.nextInt();

		Iterator<TicketCategory> itCat = tcktCateg.iterator();
		for (i = 1; i <= 3; i++) {
			if (choiceCat == i) {
				choiceCategory = itCat.next().getTicketCategoryId();
			} else {
				itCat.next();
			}
		}

		System.out.println("Enter Description related to issues: ");
		try {
			tcktDescription = buffer.readLine();

			System.out.print("Enter Priority(1. Low 2.Medium 3.High):");
			int choicePr = sc.nextInt();
			if (choicePr == 1) {
				choicePriority = "Low";
			} else if (choicePr == 2) {
				choicePriority = "Medium";
			} else if (choicePr == 3) {
				choicePriority = "High";
			}

			TicketBean tcktBean = new TicketBean(Integer.toString((int) (Math
					.random() * 1000)), choiceCategory, tcktDescription,
					choicePriority, "New", null);
			tcktSer.raiseNewTicket(tcktBean);
			System.out.println("Ticket Number "
					+ tcktBean.getTicketNo()
					+ " logged successfully at "
					+ LocalDateTime.now().format(
							DateTimeFormatter
									.ofPattern("yyyy-MMM-dd HH:mm a")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
