package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDaoImpl implements TicketDAO {

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		Util.raiseNewTicket(ticketBean);
		return true;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		Map<String, String> tcktCateg = Util.getTicketCategoryEntries();
		Iterator<String> itKey = tcktCateg.keySet().iterator();
		Iterator<String> itVal = tcktCateg.values().iterator();
		List<TicketCategory> listCat = new ArrayList<TicketCategory>();
		while (itKey.hasNext()) {
			listCat.add(new TicketCategory(itKey.next(), itVal.next()));
		}
		return listCat;
	}

}
