package com.cg.tms.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.tms.dto.TicketBean;

// Data Access Class To Perform Utility Operations
public class Util {
	public static Map<Integer, TicketBean> ticketLog = new HashMap<>();

	private static Map<String, String> ticketCategory = new HashMap<String, String>();

	public static Map<String, String> getTicketCategoryEntries() {
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		return ticketCategory;
	}

	public static void raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		ticketLog.put(Integer.parseInt(ticketBean.getTicketNo()), ticketBean);

	}

}
