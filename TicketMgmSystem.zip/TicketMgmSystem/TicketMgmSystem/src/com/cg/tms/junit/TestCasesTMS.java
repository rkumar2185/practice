package com.cg.tms.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.tms.dao.TicketDaoImpl;
import com.cg.tms.dto.TicketBean;

public class TestCasesTMS {

	static TicketDaoImpl tcktDao = null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		tcktDao = new TicketDaoImpl();
		System.out.println("...Start Class...");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("...End Class...");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("...Test Function Start...");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("...Test Function End...");
	}

	@Test
	public void testRaiseTicket() {
		Assert.assertEquals(true, tcktDao.raiseNewTicket(new TicketBean("123",
				"tc001", "Eclipse Not Working", "medium", "New", null)));
		System.out.println("testRaiseTicket Passes");
	}

}
